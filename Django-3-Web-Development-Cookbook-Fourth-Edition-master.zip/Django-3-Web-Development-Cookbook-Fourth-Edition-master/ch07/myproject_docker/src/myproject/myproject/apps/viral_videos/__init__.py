default_app_config = "myproject.apps.viral_videos.apps.ViralVideosAppConfig"
