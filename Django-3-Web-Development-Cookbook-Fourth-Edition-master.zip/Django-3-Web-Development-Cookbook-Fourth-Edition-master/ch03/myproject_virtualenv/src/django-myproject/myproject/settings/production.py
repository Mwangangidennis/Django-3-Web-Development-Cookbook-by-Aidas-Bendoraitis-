from ._base import *

DEBUG = False

WEBSITE_URL = "https://example.com"  # without trailing slash
MEDIA_URL = f"{WEBSITE_URL}/media/"
