from ._base import *

DEBUG = False

WEBSITE_URL = "https://staging.myproject.com"  # without trailing slash
MEDIA_URL = f"{WEBSITE_URL}/media/"
